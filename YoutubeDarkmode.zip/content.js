// Check for stored preference
chrome.storage.sync.get("customDarkMode", (data) => {
    if (data.customDarkMode) {
        enableDarkMode();
    }
});

// Apply styles by toggling a class on the body
function enableDarkMode() {
    document.body.classList.add("custom-dark-mode");
    console.log("Custom Dark Mode Enabled");
}

// Disable styles
function disableDarkMode() {
    document.body.classList.remove("custom-dark-mode");
    console.log("Custom Dark Mode Disabled");
}

// Add a toggle button for user convenience
const button = document.createElement("button");
button.textContent = "Toggle Dark Mode";
button.style.position = "fixed";
button.style.bottom = "10px";
button.style.right = "10px";
button.style.zIndex = "9999";
button.style.padding = "10px";
button.style.backgroundColor = "#333";
button.style.color = "#fff";
button.style.border = "none";
button.style.cursor = "pointer";
button.style.borderRadius = "5px";
button.onclick = () => {
    chrome.storage.sync.get("customDarkMode", (data) => {
        const isDarkMode = data.customDarkMode;
        chrome.storage.sync.set({ customDarkMode: !isDarkMode });
        if (!isDarkMode) enableDarkMode();
        else disableDarkMode();
    });
};
document.body.appendChild(button);
